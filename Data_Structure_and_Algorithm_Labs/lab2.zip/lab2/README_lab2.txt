********************************************
Course: COE-428
Lab#: Lab_2
Name: Shaan Hossain
Student# : 500882569
********************************************

Requirement_1: 

Question 1: Suppose that towers(5, 2, 3) is invoked. 

I. towers(4,2,1) 

II. 5 recursive calls to towers() are made before the first invocation is returned. 

III. stdout invocation of first recursive call Output:
     2 3 
IV. towers(3,2,3) 

Question 2: Suppose that towers(8, 1, 2) is invoked. How many lines will be printed to stdout? 
- 255 lines(Moves) 

Requirement_2:
Everything Works.(Error Handling)
